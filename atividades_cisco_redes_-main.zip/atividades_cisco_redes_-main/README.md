# atividades_cisco_redes_

## Objetivo
### amazenar codicos e documentação de configuraçoes dos equipamentos cisco, como router e switch baseado nas atividades do 2º termo do curso de redes de computadores.
